#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
INSTALL_ROOT="${HOUSE_STUDIO_INSTALL_ROOT:-$HOME/Library/Application Support/HouseStudio}"
APP_ROOT="$INSTALL_ROOT/app"
RUNTIME="$INSTALL_ROOT/runtime"
NODE_VERSION="v26.0.0"

case "$(uname -m)" in
  arm64) NODE_ARCH="darwin-arm64" ;;
  x86_64) NODE_ARCH="darwin-x64" ;;
  *) echo "Mac non supportato: $(uname -m)"; exit 1 ;;
esac

echo "House Studio — installazione locale per Mac"
echo "Questa edizione usa solo il progetto virtuale incluso."

# Il download resta in Download; l'app invece viene copiata in una cartella che
# macOS lascia usare ai processi locali. Cosi npm non eredita i permessi ristretti
# della cartella da cui Safari ha estratto l'archivio.
mkdir -p "$INSTALL_ROOT"
ditto "$ROOT/app" "$APP_ROOT"

if [ ! -x "$RUNTIME/bin/node" ]; then
  mkdir -p "$RUNTIME"
  TEMP_DIR="$(mktemp -d /tmp/house-studio-install.XXXXXX)"
  ARCHIVE="$TEMP_DIR/node.zip"
  echo "Scarico il runtime locale..."
  curl -fL "https://nodejs.org/dist/$NODE_VERSION/node-$NODE_VERSION-$NODE_ARCH.tar.gz" -o "$TEMP_DIR/node.tar.gz"
  tar -xzf "$TEMP_DIR/node.tar.gz" -C "$TEMP_DIR"
  cp -R "$TEMP_DIR/node-$NODE_VERSION-$NODE_ARCH/." "$RUNTIME/"
fi

echo "Installo il motore locale..."
cd "$APP_ROOT"
"$RUNTIME/bin/npm" ci --omit=dev

if [ ! -f "$APP_ROOT/apps/api/dist/index.js" ] || [ ! -f "$APP_ROOT/apps/web/dist/index.html" ]; then
  echo "Il pacchetto non e completo. Riscaricalo e riprova."
  exit 1
fi

chmod +x "$ROOT/Avvia House Studio.command"
echo ""
echo "Installazione completata. Apri Avvia House Studio.command."
