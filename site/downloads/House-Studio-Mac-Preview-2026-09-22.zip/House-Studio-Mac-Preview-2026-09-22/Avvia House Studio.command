#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
INSTALL_ROOT="${HOUSE_STUDIO_INSTALL_ROOT:-$HOME/Library/Application Support/HouseStudio}"
APP_ROOT="$INSTALL_ROOT/app"
NODE="$INSTALL_ROOT/runtime/bin/node"
DATA_DIR="$HOME/Library/Application Support/HouseStudio/data"
HOUSE_FILE="$APP_ROOT/distribution/windows/house-studio-project.json"
AUTOMATIONS_FILE="$APP_ROOT/distribution/windows/house-studio-automations.json"
PORT="18080"

if [ ! -x "$NODE" ]; then
  echo "Runtime non trovato. Apri prima Installa House Studio.command."
  exit 1
fi

mkdir -p "$DATA_DIR"
HOUSEOS_HOUSE="$HOUSE_FILE" HOUSEOS_AUTOMATION="$AUTOMATIONS_FILE" HOUSEOS_DATA="$DATA_DIR" HOUSEOS_HOST="127.0.0.1" HOUSEOS_PORT="$PORT" HOUSEOS_VIRTUAL_EDITION="1" "$NODE" "$APP_ROOT/apps/api/dist/index.js" &
SERVER_PID=$!

while [ ! -f "$DATA_DIR/admin-token" ]; do
  sleep 1
done

TOKEN="$(tr -d '\r\n' < "$DATA_DIR/admin-token")"
open "http://127.0.0.1:$PORT/#houseos-token=$TOKEN"
echo "House Studio e aperto. Lascia questa finestra aperta mentre lo usi."
wait "$SERVER_PID"
