HOUSE STUDIO — EDIZIONE ARCHITETTO (ANTEPRIMA MAC)

1. Estrai completamente questo archivio in una cartella scrivibile.
2. Apri "Installa House Studio.command" una sola volta, con connessione Internet.
3. Apri "Avvia House Studio.command".

Il pannello si apre automaticamente nel browser.

House Studio usa la porta locale 18080. Non usa la porta 8080, riservata a
un eventuale House Core gia attivo sul Mac.

TOKEN DI ACCESSO
Al primo avvio il pannello riceve automaticamente il proprio token. Se chiudi il
browser e lo riapri manualmente, House Studio puo chiedertelo: apri Finder,
premi Maiusc-Comando-G e incolla questo percorso:

~/Library/Application Support/HouseStudio/data/admin-token

Apri il file, copia l'intera riga e incollala nel pannello. Il token e personale:
non inviarlo a nessuno e non inserirlo in chat.

Il progetto di avvio e' "Nuovo progetto": una casa virtuale generica.
Non include dati, capitolati, automazioni o configurazioni di Via Silva.
