@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Installa-House-Studio.ps1"
pause
