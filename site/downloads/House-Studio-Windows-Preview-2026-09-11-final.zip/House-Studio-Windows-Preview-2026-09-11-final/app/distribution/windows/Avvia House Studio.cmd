@echo off
setlocal
set "APP_ROOT=%~dp0app"
set "RUNTIME=%~dp0runtime\node.exe"
set "HOUSEOS_HOUSE=%APP_ROOT%\distribution\windows\house-studio-project.json"
set "HOUSEOS_AUTOMATION=%APP_ROOT%\distribution\windows\house-studio-automations.json"
set "HOUSEOS_DATA=%LOCALAPPDATA%\HouseStudio\data"
set "HOUSEOS_HOST=127.0.0.1"
set "HOUSEOS_PORT=8080"

if not exist "%HOUSEOS_DATA%" mkdir "%HOUSEOS_DATA%"

if not exist "%RUNTIME%" (
  echo Runtime non trovato. Esegui prima Installa House Studio.cmd.
  pause
  exit /b 1
)

if not exist "%APP_ROOT%\apps\api\dist\index.js" (
  echo Applicazione non compilata. Esegui prima Installa House Studio.cmd.
  pause
  exit /b 1
)

start "House Studio — chiudi questa finestra per spegnere il progetto" "%RUNTIME%" "%APP_ROOT%\apps\api\dist\index.js"

:wait_for_token
if exist "%HOUSEOS_DATA%\admin-token" goto open_panel
timeout /t 1 /nobreak >nul
goto wait_for_token

:open_panel
set /p HOUSEOS_TOKEN=<"%HOUSEOS_DATA%\admin-token"
start "" "http://127.0.0.1:8080/#houseos-token=%HOUSEOS_TOKEN%"
