$ErrorActionPreference = 'Stop'
$root = Join-Path $PSScriptRoot 'app'
$runtime = Join-Path $PSScriptRoot 'runtime'
$nodeVersion = 'v26.0.0'
$nodeZip = Join-Path $env:TEMP "node-$nodeVersion-win-x64.zip"
$nodeUrl = "https://nodejs.org/dist/$nodeVersion/node-$nodeVersion-win-x64.zip"

Write-Host 'House Studio — installazione locale per Windows' -ForegroundColor Cyan
Write-Host 'Questa edizione usa solo il progetto virtuale incluso. Non carica dati di House Core Demo.'

if (-not (Test-Path (Join-Path $runtime 'node.exe'))) {
  New-Item -ItemType Directory -Force -Path $runtime | Out-Null
  Write-Host 'Scarico il runtime locale...'
  Invoke-WebRequest -Uri $nodeUrl -OutFile $nodeZip
  Expand-Archive -Path $nodeZip -DestinationPath $env:TEMP -Force
  Copy-Item -Path (Join-Path $env:TEMP "node-$nodeVersion-win-x64\*") -Destination $runtime -Recurse -Force
}

$node = Join-Path $runtime 'node.exe'
$npm = Join-Path $runtime 'npm.cmd'
Push-Location $root
try {
  Write-Host 'Installo il motore locale...'
  & $npm ci --omit=dev
  if ($LASTEXITCODE -ne 0) { throw 'npm ci non riuscito.' }
  if (-not (Test-Path (Join-Path $root 'apps\\api\\dist\\index.js'))) { throw 'Motore locale mancante dal pacchetto.' }
  if (-not (Test-Path (Join-Path $root 'apps\\web\\dist\\index.html'))) { throw 'Pannello web mancante dal pacchetto.' }
} finally {
  Pop-Location
}

Write-Host ''
Write-Host 'Installazione completata. Avvia "Avvia House Studio.cmd".' -ForegroundColor Green
