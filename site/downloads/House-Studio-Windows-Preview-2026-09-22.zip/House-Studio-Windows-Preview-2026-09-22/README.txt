HOUSE STUDIO — EDIZIONE ARCHITETTO (ANTEPRIMA)

1. Estrai completamente questo archivio in una cartella scrivibile, ad esempio Desktop\House-Studio.
2. Esegui "Installa House Studio.cmd" una sola volta, con connessione Internet.
3. Esegui "Avvia House Studio.cmd". Il pannello si apre automaticamente.

Il progetto di avvio e' "Nuovo progetto": e' una casa virtuale generica.
Non include dati, capitolati, automazioni o configurazioni di House Core Demo.

La prima installazione scarica il runtime Node locale e le dipendenze necessarie.
Il motore e il pannello sono gia inclusi nel pacchetto. Dopo l'installazione House
Studio gira in locale su http://127.0.0.1:8080.
