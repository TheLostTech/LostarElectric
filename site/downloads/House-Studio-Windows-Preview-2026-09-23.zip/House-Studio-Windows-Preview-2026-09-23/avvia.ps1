﻿# House Studio per Windows: accende la casa senza nessuna finestra e apre il pannello.
# Se e gia accesa chiede se aprire il pannello o spegnerla.
# Uso di prova: -Silenzioso [-Scelta Apri|Spegni] (nessuna finestra, nessun browser)
param([switch]$Silenzioso, [string]$Scelta)

$ErrorActionPreference = 'Stop'
$Titolo = 'House Studio'
$Cartella = $PSScriptRoot
$App = Join-Path $Cartella 'app'
$Node = Join-Path $Cartella 'runtime\node.exe'
$Dati = Join-Path $env:LOCALAPPDATA 'HouseStudio\data'
$Registro = Join-Path $Cartella 'house-studio.log'
$Porta = 18080
if ($env:HOUSE_STUDIO_PORT) { $Porta = [int]$env:HOUSE_STUDIO_PORT }
if ($env:HOUSE_STUDIO_DATA) { $Dati = $env:HOUSE_STUDIO_DATA }

if (-not $Silenzioso) { Add-Type -AssemblyName System.Windows.Forms }
function Messaggio([string]$testo, [string]$icona = 'Information') {
  if ($Silenzioso) { Write-Output $testo; return }
  [void][System.Windows.Forms.MessageBox]::Show($testo, $Titolo, 'OK', $icona)
}
function Risponde {
  try { Invoke-WebRequest -UseBasicParsing -TimeoutSec 2 "http://127.0.0.1:$Porta/health" | Out-Null; return $true } catch { return $false }
}
function ApriPannello {
  if ($Silenzioso) { Write-Output 'PANNELLO'; return }
  $token = (Get-Content -Raw (Join-Path $Dati 'admin-token')).Trim()
  Start-Process "http://127.0.0.1:$Porta/#houseos-token=$token"
}

if (-not (Test-Path $Node) -or -not (Test-Path (Join-Path $App 'apps\api\dist\custode.js'))) {
  Messaggio 'House Studio non e installato completamente. Esegui di nuovo Installa House Studio.' 'Error'
  exit 1
}
New-Item -ItemType Directory -Force -Path $Dati | Out-Null

# Gia accesa? Lo dice il lucchetto, se il processo e ancora vivo.
$lucchetto = Join-Path $Dati 'casa.lock'
if (Test-Path $lucchetto) {
  $casaPid = $null
  try { $casaPid = [int](Get-Content -Raw $lucchetto | ConvertFrom-Json).pid } catch { }
  $processo = $null
  if ($casaPid) { $processo = Get-Process -Id $casaPid -ErrorAction SilentlyContinue }
  if ($processo) {
    if (-not $Scelta) {
      $r = [System.Windows.Forms.MessageBox]::Show(
        "House Studio e acceso.`r`n`r`nSi: apri il pannello`r`nNo: spegni House Studio", $Titolo, 'YesNoCancel', 'Question')
      if ($r -eq 'Yes') { $Scelta = 'Apri' } elseif ($r -eq 'No') { $Scelta = 'Spegni' } else { exit 0 }
    }
    if ($Scelta -eq 'Spegni') {
      # Su Windows un processo senza finestra non riceve lo spegnimento ordinato: si ferma la casa,
      # il custode esce con lei, e il lucchetto rimasto viene riconosciuto al prossimo avvio.
      Stop-Process -Id $casaPid -Force
      Messaggio 'House Studio e spento.'
    } else {
      ApriPannello
    }
    exit 0
  }
}

$occupata = Get-NetTCPConnection -LocalPort $Porta -State Listen -ErrorAction SilentlyContinue
if ($occupata) {
  Messaggio "La porta $Porta e occupata da un altro programma. Chiudilo e riapri House Studio." 'Warning'
  exit 1
}

$env:HOUSEOS_HOUSE = Join-Path $App 'distribution\windows\house-studio-project.json'
$env:HOUSEOS_AUTOMATION = Join-Path $App 'distribution\windows\house-studio-automations.json'
$env:HOUSEOS_DATA = $Dati
$env:HOUSEOS_HOST = '127.0.0.1'
$env:HOUSEOS_PORT = "$Porta"
"--- $(Get-Date -Format s) avvio" | Out-File -Append -Encoding utf8 $Registro

# Nessuna finestra: il custode nasce senza console e scrive nel registro.
$info = New-Object System.Diagnostics.ProcessStartInfo
$info.FileName = Join-Path $env:SystemRoot 'System32\cmd.exe'
$info.Arguments = "/d /c `"`"$Node`" `"$(Join-Path $App 'apps\api\dist\custode.js')`" >> `"$Registro`" 2>&1`""
$info.WorkingDirectory = $App
$info.UseShellExecute = $false
$info.CreateNoWindow = $true
[void][System.Diagnostics.Process]::Start($info)

for ($i = 0; $i -lt 90; $i++) {
  if (Risponde) { ApriPannello; exit 0 }
  Start-Sleep -Seconds 1
}
Messaggio "House Studio non risponde. I dettagli sono in $Registro" 'Error'
exit 1
