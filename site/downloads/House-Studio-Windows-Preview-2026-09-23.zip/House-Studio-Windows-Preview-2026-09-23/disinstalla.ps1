﻿# Disinstalla House Studio: toglie il programma e le icone. I progetti restano, se non chiedi di cancellarli.
param([switch]$Silenzioso)
$Titolo = 'House Studio'
$Cartella = $PSScriptRoot
$Dati = Join-Path $env:LOCALAPPDATA 'HouseStudio'
if (-not $Silenzioso) {
  Add-Type -AssemblyName System.Windows.Forms
  $r = [System.Windows.Forms.MessageBox]::Show(
    "Disinstallo House Studio da:`r`n$Cartella`r`n`r`nVuoi cancellare anche i tuoi progetti?`r`nSi: cancella tutto`r`nNo: tieni i progetti",
    $Titolo, 'YesNoCancel', 'Question')
  if ($r -eq 'Cancel') { exit 0 }
  $cancellaDati = ($r -eq 'Yes')
} else { $cancellaDati = $false }

# Se e accesa si ferma, senza passare dall'avvio (che una casa spenta la accenderebbe).
$DatiCasa = Join-Path $Dati 'data'
if ($env:HOUSE_STUDIO_DATA) { $DatiCasa = $env:HOUSE_STUDIO_DATA }
$lucchetto = Join-Path $DatiCasa 'casa.lock'
if (Test-Path $lucchetto) {
  try { $casaPid = [int](Get-Content -Raw $lucchetto | ConvertFrom-Json).pid; Stop-Process -Id $casaPid -Force -ErrorAction SilentlyContinue } catch { }
}
Start-Sleep -Seconds 2
$menu = Join-Path ([Environment]::GetFolderPath('Programs')) 'House Studio'
Remove-Item -Recurse -Force $menu -ErrorAction SilentlyContinue
Remove-Item -Force (Join-Path ([Environment]::GetFolderPath('Desktop')) 'House Studio.lnk') -ErrorAction SilentlyContinue
if ($cancellaDati) { Remove-Item -Recurse -Force $Dati -ErrorAction SilentlyContinue }
# La cartella del programma si toglie dopo l'uscita di questo script, che vive li dentro.
Start-Process -FilePath (Join-Path $env:SystemRoot 'System32\cmd.exe') -WindowStyle Hidden `
  -ArgumentList "/d /c timeout /t 2 /nobreak >nul & rmdir /s /q `"$Cartella`""
if (-not $Silenzioso) { [void][System.Windows.Forms.MessageBox]::Show('House Studio e disinstallato.', $Titolo, 'OK', 'Information') }
