﻿# House Studio per Windows: installazione con una piccola finestra, senza console.
# Uso normale: doppio clic su "Installa House Studio.cmd".
# Uso di prova senza finestre: -Silenzioso -Cartella C:\percorso
param([switch]$Silenzioso, [string]$Cartella)

$ErrorActionPreference = 'Stop'
$NodeVersion = 'v26.10.0'
$Titolo = 'House Studio'
$Sorgente = $PSScriptRoot
$Predefinita = Join-Path $env:LOCALAPPDATA 'Programs\House Studio'

if (-not $Silenzioso) {
  Add-Type -AssemblyName System.Windows.Forms
  Add-Type -AssemblyName System.Drawing
  [System.Windows.Forms.Application]::EnableVisualStyles()
}

function Messaggio([string]$testo, [string]$icona = 'Information') {
  if ($Silenzioso) { Write-Output $testo; return }
  [void][System.Windows.Forms.MessageBox]::Show($testo, $Titolo, 'OK', $icona)
}

# ---- 1. La cartella di destinazione, mostrata e modificabile ----
if ($Silenzioso) {
  if (-not $Cartella) { $Cartella = $Predefinita }
} else {
  $form = New-Object System.Windows.Forms.Form
  $form.Text = 'Installa House Studio'
  $form.Size = New-Object System.Drawing.Size(560, 290)
  $form.StartPosition = 'CenterScreen'
  $form.FormBorderStyle = 'FixedDialog'
  $form.MaximizeBox = $false
  $form.MinimizeBox = $false
  $iconaFile = Join-Path $Sorgente 'house-studio.ico'
  if (Test-Path $iconaFile) { $form.Icon = New-Object System.Drawing.Icon($iconaFile) }

  $intro = New-Object System.Windows.Forms.Label
  $intro.Text = "House Studio si installa nella cartella qui sotto. La prima installazione scarica il motore locale: serve internet per qualche minuto.`r`n`r`nCartella di installazione:"
  $intro.Location = New-Object System.Drawing.Point(20, 18)
  $intro.Size = New-Object System.Drawing.Size(510, 75)
  $form.Controls.Add($intro)

  $campo = New-Object System.Windows.Forms.TextBox
  $campo.Text = $Predefinita
  $campo.Location = New-Object System.Drawing.Point(20, 98)
  $campo.Size = New-Object System.Drawing.Size(400, 24)
  $form.Controls.Add($campo)

  $sfoglia = New-Object System.Windows.Forms.Button
  $sfoglia.Text = 'Sfoglia...'
  $sfoglia.Location = New-Object System.Drawing.Point(430, 96)
  $sfoglia.Size = New-Object System.Drawing.Size(95, 28)
  $sfoglia.Add_Click({
    $scelta = New-Object System.Windows.Forms.FolderBrowserDialog
    $scelta.Description = 'Scegli dove installare House Studio'
    $scelta.ShowNewFolderButton = $true
    if ($scelta.ShowDialog() -eq 'OK') { $campo.Text = Join-Path $scelta.SelectedPath 'House Studio' }
  })
  $form.Controls.Add($sfoglia)

  $desktop = New-Object System.Windows.Forms.CheckBox
  $desktop.Text = "Crea l'icona sul Desktop"
  $desktop.Checked = $true
  $desktop.Location = New-Object System.Drawing.Point(20, 138)
  $desktop.Size = New-Object System.Drawing.Size(400, 24)
  $form.Controls.Add($desktop)

  $ok = New-Object System.Windows.Forms.Button
  $ok.Text = 'Installa'
  $ok.Location = New-Object System.Drawing.Point(330, 200)
  $ok.Size = New-Object System.Drawing.Size(95, 30)
  $ok.DialogResult = 'OK'
  $form.AcceptButton = $ok
  $form.Controls.Add($ok)

  $annulla = New-Object System.Windows.Forms.Button
  $annulla.Text = 'Annulla'
  $annulla.Location = New-Object System.Drawing.Point(430, 200)
  $annulla.Size = New-Object System.Drawing.Size(95, 30)
  $annulla.DialogResult = 'Cancel'
  $form.CancelButton = $annulla
  $form.Controls.Add($annulla)

  if ($form.ShowDialog() -ne 'OK') { exit 0 }
  $Cartella = $campo.Text.Trim()
  $conIconaDesktop = $desktop.Checked
}
if ($Silenzioso) { $conIconaDesktop = $true }
if (-not $Cartella) { Messaggio 'Serve una cartella di installazione.' 'Warning'; exit 1 }

# ---- 2. La finestra di avanzamento ----
$avanzamento = $null
$stato = $null
if (-not $Silenzioso) {
  $avanzamento = New-Object System.Windows.Forms.Form
  $avanzamento.Text = 'Installo House Studio'
  $avanzamento.Size = New-Object System.Drawing.Size(460, 160)
  $avanzamento.StartPosition = 'CenterScreen'
  $avanzamento.FormBorderStyle = 'FixedDialog'
  $avanzamento.ControlBox = $false
  if ($form.Icon) { $avanzamento.Icon = $form.Icon }
  $stato = New-Object System.Windows.Forms.Label
  $stato.Location = New-Object System.Drawing.Point(20, 20)
  $stato.Size = New-Object System.Drawing.Size(410, 40)
  $avanzamento.Controls.Add($stato)
  $barra = New-Object System.Windows.Forms.ProgressBar
  $barra.Style = 'Marquee'
  $barra.MarqueeAnimationSpeed = 30
  $barra.Location = New-Object System.Drawing.Point(20, 70)
  $barra.Size = New-Object System.Drawing.Size(410, 20)
  $avanzamento.Controls.Add($barra)
  $avanzamento.Show()
}
function Passo([string]$testo) {
  if ($Silenzioso) { Write-Output $testo; return }
  $stato.Text = $testo
  [System.Windows.Forms.Application]::DoEvents()
}
# Aspetta un processo senza bloccare la finestra.
function Attendi($processo) {
  while (-not $processo.HasExited) {
    if (-not $Silenzioso) { [System.Windows.Forms.Application]::DoEvents() }
    Start-Sleep -Milliseconds 200
  }
  return $processo.ExitCode
}

$registro = $null
try {
  New-Item -ItemType Directory -Force -Path $Cartella | Out-Null
  $registro = Join-Path $Cartella 'installazione.log'
  "--- $(Get-Date -Format s) installazione in $Cartella" | Out-File -Append -Encoding utf8 $registro

  if (-not (Test-Path (Join-Path $Sorgente 'app\PAYLOAD-SHA256.json'))) {
    throw "Il pacchetto e incompleto. Estrai tutto l'archivio e riprova."
  }

  # Il runtime locale.
  $runtime = Join-Path $Cartella 'runtime'
  if (-not (Test-Path (Join-Path $runtime 'node.exe'))) {
    Passo 'Scarico il motore locale...'
    $zip = Join-Path $env:TEMP "node-$NodeVersion-win-x64.zip"
    $client = New-Object System.Net.WebClient
    $scarico = $client.DownloadFileTaskAsync("https://nodejs.org/dist/$NodeVersion/node-$NodeVersion-win-x64.zip", $zip)
    while (-not $scarico.IsCompleted) {
      if (-not $Silenzioso) { [System.Windows.Forms.Application]::DoEvents() }
      Start-Sleep -Milliseconds 200
    }
    if ($scarico.IsFaulted) { throw 'Non riesco a scaricare il motore. Controlla la connessione a internet.' }
    Passo 'Preparo il motore locale...'
    $estratto = Join-Path $env:TEMP "house-studio-node-$PID"
    Expand-Archive -Path $zip -DestinationPath $estratto -Force
    New-Item -ItemType Directory -Force -Path $runtime | Out-Null
    Copy-Item -Path (Join-Path $estratto "node-$NodeVersion-win-x64\*") -Destination $runtime -Recurse -Force
    Remove-Item -Recurse -Force $estratto, $zip -ErrorAction SilentlyContinue
  }

  # Il programma va nella sua cartella definitiva PRIMA di npm: su Windows npm collega i pacchetti
  # interni con junction a percorso assoluto, e una rinomina successiva le lascerebbe vuote.
  # La versione precedente resta da parte finche l'installazione non e riuscita.
  Passo 'Copio House Studio...'
  $app = Join-Path $Cartella 'app'
  $vecchia = Join-Path $Cartella 'app.precedente'
  if (Test-Path $vecchia) { Remove-Item -Recurse -Force $vecchia }
  if (Test-Path $app) { Rename-Item $app 'app.precedente' }
  Copy-Item -Path (Join-Path $Sorgente 'app') -Destination $app -Recurse -Force

  Passo 'Installo il motore di House Studio... (qualche minuto)'
  $npm = Join-Path $runtime 'npm.cmd'
  $env:Path = "$runtime;$env:Path"
  $npmLog = Join-Path $Cartella 'npm.log'
  # Nessuna finestra: il processo nasce senza console, e l'uscita va nel registro.
  $info = New-Object System.Diagnostics.ProcessStartInfo
  $info.FileName = Join-Path $env:SystemRoot 'System32\cmd.exe'
  $info.Arguments = "/d /c `"`"$npm`" ci --omit=dev --no-audit --no-fund > `"$npmLog`" 2>&1`""
  $info.WorkingDirectory = $app
  $info.UseShellExecute = $false
  $info.CreateNoWindow = $true
  $processo = [System.Diagnostics.Process]::Start($info)
  if ((Attendi $processo) -ne 0) {
    Remove-Item -Recurse -Force $app -ErrorAction SilentlyContinue
    if (Test-Path $vecchia) { Rename-Item $vecchia 'app' }
    throw "Installazione non riuscita. I dettagli sono in $npmLog"
  }
  if (Test-Path $vecchia) { Remove-Item -Recurse -Force $vecchia }

  foreach ($file in 'avvia.ps1', 'disinstalla.ps1', 'house-studio.ico') {
    Copy-Item -Path (Join-Path $Sorgente $file) -Destination (Join-Path $Cartella $file) -Force
  }
  # I file arrivati da internet portano il segno della zona: si tolgono, cosi Windows non li ferma.
  Get-ChildItem -Path $Cartella -Recurse -Include *.ps1 | Unblock-File

  # Le icone: si avvia senza nessuna finestra di console.
  Passo 'Creo le icone...'
  $shell = New-Object -ComObject WScript.Shell
  $powershell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
  function Collegamento([string]$percorso, [string]$script) {
    $c = $shell.CreateShortcut($percorso)
    $c.TargetPath = $powershell
    $c.Arguments = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$(Join-Path $Cartella $script)`""
    $c.WorkingDirectory = $Cartella
    $c.IconLocation = Join-Path $Cartella 'house-studio.ico'
    $c.WindowStyle = 7
    $c.Save()
  }
  $menu = Join-Path ([Environment]::GetFolderPath('Programs')) 'House Studio'
  New-Item -ItemType Directory -Force -Path $menu | Out-Null
  Collegamento (Join-Path $menu 'House Studio.lnk') 'avvia.ps1'
  Collegamento (Join-Path $menu 'Disinstalla House Studio.lnk') 'disinstalla.ps1'
  if ($conIconaDesktop) {
    Collegamento (Join-Path ([Environment]::GetFolderPath('Desktop')) 'House Studio.lnk') 'avvia.ps1'
  }
  "--- $(Get-Date -Format s) installazione completata" | Out-File -Append -Encoding utf8 $registro
} catch {
  if ($registro) { "ERRORE $($_.Exception.Message)" | Out-File -Append -Encoding utf8 $registro }
  if ($avanzamento) { $avanzamento.Close() }
  Messaggio $_.Exception.Message 'Error'
  exit 1
}

if ($avanzamento) { $avanzamento.Close() }
if ($Silenzioso) { Write-Output "Installato in $Cartella"; exit 0 }
$apri = [System.Windows.Forms.MessageBox]::Show(
  "House Studio e installato in:`r`n$Cartella`r`n`r`nLo trovi sul Desktop e nel menu Start. Vuoi aprirlo adesso?",
  $Titolo, 'YesNo', 'Information')
if ($apri -eq 'Yes') {
  Start-Process -FilePath $powershell -ArgumentList '-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', "`"$(Join-Path $Cartella 'avvia.ps1')`"" -WindowStyle Hidden
}
